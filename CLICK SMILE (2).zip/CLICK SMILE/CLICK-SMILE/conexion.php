<?php
// Configuración de la conexión a la base de datos
$SERVER= "localhost";
$USER = "root";
$PASS = "";
$DB = "cs";

// Crear una nueva conexión a la base de datos
$CONEXION = new mysqli($SERVER, $USER, $PASS, $DB);

// Verificar si la conexión fue exitosa
if ($CONEXION->connect_errno) {
    // Mostrar un mensaje de error si la conexión falló
    die("Conexión fallida: ". $CONEXION->connect_errno);
} else {
    // Mostrar un mensaje de éxito si la conexión fue exitosa
    echo "Conectado";
}
?>