
<?php
$nombre = $_POST["Nombre"];
$apellidos = $_POST["Apellidos"];
$edad = $_POST["Edad"];
$sexo = $_POST["Sexo"];
$direccion = $_POST["Direccion"];
$telefono = $_POST["Telefono"];
$fecha = $_POST["Fecha"];
$hora = $_POST["Hora"];

// Insertar en la tabla "cliente"
$sql1 = "INSERT INTO cl (nombre, apellidos, edad, sexo, direccion, telefono)
        VALUES ('$nombre', '$apellidos', '$edad', '$sexo', '$direccion', '$telefono')";
    

if ($conn->query($sql1) === TRUE) {
    // Obtener el ID generado en la inserción anterior
    $cliente_id = $conn->insert_id;

    // Insertar en la tabla "consulta"
    $sql2 = "INSERT INTO consulta. (fecha, hora, cliente_id)
            VALUES ('$fecha', '$hora', '$cliente_id')";

    if ($conn->query($sql2) === TRUE) {
        echo "Datos guardados correctamente";
    } else {
        echo "Error al guardar la fecha y hora: " . $sql2 . "<br>" . $conn->error;
    }
} else {
    echo "Error al guardar los datos personales: " . $sql1 . "<br>" . $conn->error;
}

$conn->close();
?>

