document.getElementById("enviar_info").addEventListener("click", function(event) {
    event.preventDefault();
    
    var form = new FormData();

    var xhr = new XMLHttpRequest();
    xhr.open("POST", "guardar.php", true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            alert("Datos guardados correctamente");
            form.reset();
        } else { 
            alert("Error al guardar los datos");
        }
    };
    xhr.send(form);
});
